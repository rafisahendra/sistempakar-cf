-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2019 at 04:38 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cf_motor`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE IF NOT EXISTS `administrator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nama` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id`, `username`, `password`, `nama`) VALUES
(1, 'admin', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `balas_pesan`
--

CREATE TABLE IF NOT EXISTS `balas_pesan` (
  `id_balas` int(11) NOT NULL AUTO_INCREMENT,
  `id_member` int(11) NOT NULL,
  `id_pesan` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `waktu` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_balas`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `balas_pesan`
--

INSERT INTO `balas_pesan` (`id_balas`, `id_member`, `id_pesan`, `pesan`, `status`, `waktu`) VALUES
(11, 1, 18, 'Boleh  tntang apa gan?', 'notyet', '2019-11-14 16:36:55'),
(12, 1, 19, 'Kendalanya dimana bg?', 'notyet', '2019-11-14 16:37:50');

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE IF NOT EXISTS `gejala` (
  `id_gejala` int(11) NOT NULL AUTO_INCREMENT,
  `kd_gejala` varchar(5) NOT NULL,
  `kd_kerusakan` varchar(5) NOT NULL,
  `nama_gejala` text NOT NULL,
  PRIMARY KEY (`id_gejala`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `kd_gejala`, `kd_kerusakan`, `nama_gejala`) VALUES
(1, 'G01', 'K01', 'Mesin tidak bisa di starter serta sistem kelistrikan tidak kuat'),
(2, 'G02', 'K01', 'Mesin terdengar suara ketukan secara berturut-turut dengan cepat'),
(3, 'G03', 'K01', 'Mesin tidak bisa di starter serta terrdengar suara KLIK satu kali ketika di starter'),
(4, 'G04', 'K02', 'Keluar uap asap dalam jumlah banyak dari radiator'),
(5, 'G05', 'K02', 'Mesin overhead'),
(6, 'G06', 'K02', 'Indikator tekanan air manyala'),
(7, 'G07', 'K02', 'Tekanan air naik'),
(8, 'G08', 'K02', 'Air radiator berkurang setiap beberapa saat'),
(9, 'G09', 'K03', 'Suara starter loss'),
(10, 'G10', 'K03', 'Terasa berat ketika akan di starter'),
(11, 'G11', 'K03', 'Timbul suara kasar saat tombol elektrik starter dipencet'),
(12, 'G12', 'K04', 'Tenaga mesin berkurang'),
(13, 'G13', 'K04', 'Mesin sering kehilangan tenaga pada saat putaran tinggi'),
(14, 'G14', 'K04', 'Mesin menyala beberapa saat kemudian kemudian mati secara perlahan'),
(15, 'G15', 'K04', 'Putaran mesin saat idle tidak nornal serta tenaga kurang');

-- --------------------------------------------------------

--
-- Table structure for table `hasil_konsultasi`
--

CREATE TABLE IF NOT EXISTS `hasil_konsultasi` (
  `id_hasilkonsultasi` int(11) NOT NULL AUTO_INCREMENT,
  `no_konsul` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `kd_kerusakan` varchar(5) NOT NULL,
  `cf1` double NOT NULL,
  `cf2` double NOT NULL,
  `cf3` double NOT NULL,
  `cf4` double NOT NULL,
  `max` double NOT NULL,
  `waktu` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_hasilkonsultasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `hasil_konsultasi`
--


-- --------------------------------------------------------

--
-- Table structure for table `kerusakan`
--

CREATE TABLE IF NOT EXISTS `kerusakan` (
  `id_kerusakan` int(11) NOT NULL AUTO_INCREMENT,
  `kd_kerusakan` varchar(5) NOT NULL,
  `nama_kerusakan` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `penanggulangan` text NOT NULL,
  PRIMARY KEY (`id_kerusakan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `kerusakan`
--

INSERT INTO `kerusakan` (`id_kerusakan`, `kd_kerusakan`, `nama_kerusakan`, `keterangan`, `penanggulangan`) VALUES
(1, 'K01', 'Accu Low', 'Accu Adalah Penyumbang daya Listrik motor menggunakan Lower', 'Periksa air Accu apakah berada di antara garis opper Level atau lower level apabila terletak pada baris lower level maka segera lakukan penambahan air Accu Periksa sambungan di sambungan Accu apakah kendor atau tidak.periksa kepala terminal positive (+) dan negative (-) Apakah  Accu apakah kotor atau tidak. Apabila kotor lakukan pembersihan sehingga tidak ada hambaatan untuk arus listrik.'),
(2, 'K02', 'Radiator Bocor atau Rusak', 'Apabila Air Radiator Bocor atau Rusak', '<br />\r\nApabila air radiator habis pada saat mesin menyala maka segera matikan mesin dan tunggu sampai dingin kembali kemudian isi kembali air radiator serta periksa apakah ada air yang menetes dari komponen radiator pada saat air radiator sudah di isi. apabila ada menetes maka terdapat kebocoran maka segera periksa darimana kebocoran tersebut dan perbaiki.</br>- Periksa apakah tutup radiator sudaah rapat atau belum.</br>- Periksa komponen radiator dan setiap sambungan selang atau sudah pas pada saat sudah dipasang.</br>- Periksa gasket pada mesin apakah masih bagus atau ada yang sudah terkoak sehingga air meewati celah antar mesin.</br>- Apabila kebocoran terdapat pada sirip-sirip radiator maka harus dibawa ke service radiator. '),
(3, 'K03', 'Motor Stater Rusak', '<br />\r\nMotor Staer Rrusak disebabkan Oleh Swice atau dinamo dan Kmparan yang rusak', 'Lakukan Pemeriksaan pada dinamo starter seperti, Swich Kontak starter, Swich dinamo starter, Kumparan dinamo starter, karbon brush dan periksa apakah ada komponen yang sudah aus atau sudah mungkin terbakar, Jika ada lalkukan penggantian komponen yang rusak'),
(4, 'K04', 'Saringan bahan bakar kotor atau terdapat kebocoran pada sistem bahan bakar', 'Saringan bahan bakar rusak dan kebocoran pada istem bahan bakar', 'Lakukan pemberrsihan filter udara setiap 3000 km untuk penggunaan di medan yang berdebu dan 30000 km untuk medan biasa. Lakukan pembersihan saringan bahan bakar apabila kotor, dan lakukan penggantian saringan apabila sudah tiba waktunya.<br />\r\nPeriksa saluran bahan bakar apakah terdapat kebocoran pada komponen sehingga menyebabkan saluran bahan bakar berecanpur dengan air dan lakukan pembungan udara apabila terdapat udara di dalam sauran bahan bakar.<br />\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `konsultasi`
--

CREATE TABLE IF NOT EXISTS `konsultasi` (
  `id_konsultasi` int(11) NOT NULL AUTO_INCREMENT,
  `no_konsul` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `kd_gejala` varchar(5) NOT NULL,
  `cf` double NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_konsultasi`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=255 ;

--
-- Dumping data for table `konsultasi`
--


-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id_member` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(15) NOT NULL,
  `jk` varchar(6) NOT NULL,
  `alamat` text NOT NULL,
  `tgl_lahir` date NOT NULL DEFAULT '0000-00-00',
  `username` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id_member`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id_member`, `nama`, `jk`, `alamat`, `tgl_lahir`, `username`, `password`) VALUES
(1, 'rafi sahendra', 'pria', 'padang Barat', '1996-11-30', 'rafi', 'rafi'),
(3, 'gema fajar', 'pria', 'Lubuk mimnturun, Padang, sumatra barat', '1985-08-23', 'gemafajar', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `pesanm`
--

CREATE TABLE IF NOT EXISTS `pesanm` (
  `id_pesanm` int(11) NOT NULL AUTO_INCREMENT,
  `id_member` int(11) NOT NULL,
  `id_balas` int(11) NOT NULL,
  `pesan` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `waktu` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_pesanm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `pesanm`
--

INSERT INTO `pesanm` (`id_pesanm`, `id_member`, `id_balas`, `pesan`, `status`, `waktu`) VALUES
(18, 1, 0, 'Mau Konsultasi bisa bg?', 'ok', '2019-11-14 16:36:32'),
(19, 1, 11, 'Tentang penggunaan bg', 'ok', '2019-11-14 16:37:16');
